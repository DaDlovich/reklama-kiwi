// Reklama KiWi — small interactions (no libraries needed)
(function () {
  // Footer year
  document.querySelectorAll("footer div").forEach(function (el) {
    if (el.children.length === 0 && /©\s*\d{4}/.test(el.textContent)) {
      el.textContent = el.textContent.replace(/©\s*\d{4}/, "© " + new Date().getFullYear());
    }
  });

  // Mobile menu
  var toggle = document.getElementById("menu-toggle");
  var menu = document.getElementById("mobile-menu");
  if (toggle && menu) {
    var openIcon = toggle.innerHTML;
    var closeIcon = document.getElementById("close-icon-template");
    toggle.addEventListener("click", function () {
      var isOpen = menu.hasAttribute("hidden");
      if (isOpen) menu.removeAttribute("hidden"); else menu.setAttribute("hidden", "");
      toggle.setAttribute("aria-expanded", String(isOpen));
      toggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
      toggle.innerHTML = isOpen && closeIcon ? closeIcon.innerHTML : openIcon;
    });
  }

  // Work page: category filter
  var ACTIVE = ["border-primary", "bg-primary", "text-primary-foreground"];
  var IDLE = ["border-border", "text-muted-foreground", "hover:border-primary", "hover:text-foreground"];
  var filters = document.querySelectorAll("[data-filter]");
  var cards = document.querySelectorAll("[data-category]");
  filters.forEach(function (btn) {
    btn.addEventListener("click", function () {
      var f = btn.getAttribute("data-filter");
      filters.forEach(function (b) {
        var on = b === btn;
        ACTIVE.forEach(function (c) { b.classList.toggle(c, on); });
        IDLE.forEach(function (c) { b.classList.toggle(c, !on); });
      });
      cards.forEach(function (card) {
        card.style.display = f === "All" || card.getAttribute("data-category") === f ? "" : "none";
      });
    });
  });

  // Work page: photo pop-up
  var lb = document.getElementById("lightbox");
  if (lb && window.KIWI_WORKS) {
    var img = document.getElementById("lb-img");
    function close() { lb.setAttribute("hidden", ""); document.body.style.overflow = ""; }
    cards.forEach(function (card) {
      card.addEventListener("click", function () {
        var w = window.KIWI_WORKS[card.getAttribute("data-id")];
        if (!w) return;
        img.src = w.image; img.alt = w.title;
        document.getElementById("lb-cat").textContent = w.category;
        document.getElementById("lb-title").textContent = w.title;
        document.getElementById("lb-desc").textContent = w.description;
        lb.removeAttribute("hidden");
        document.body.style.overflow = "hidden";
      });
    });
    lb.addEventListener("click", function (e) {
      if (e.target === lb || e.target.closest(".kiwi-lightbox__close")) close();
    });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });
  }
})();

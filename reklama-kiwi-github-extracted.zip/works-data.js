// Portfolio items: edit titles and descriptions here.
window.KIWI_WORKS = {
  "instalcentr": {
    "id": "instalcentr",
    "title": "Instalcentr storefront",
    "category": "Facade signs",
    "description": "Full storefront branding with volume letters and a lit logo for an engineering-systems store.",
    "image": "images/storefront-instalcentr.jpg"
  },
  "vilis-backlit": {
    "id": "vilis-backlit",
    "title": "Vilis backlit logo",
    "category": "Light signs",
    "description": "Halo-lit logo panel that glows softly against the wall.",
    "image": "images/backlit-logo-vilis.jpg"
  },
  "vilis-facade": {
    "id": "vilis-facade",
    "title": "Vilis facade sign",
    "category": "Facade signs",
    "description": "Clean dimensional sign mounted high on a modern building facade.",
    "image": "images/facade-sign-vilis.jpg"
  },
  "led-night": {
    "id": "led-night",
    "title": "LED pixel sign",
    "category": "Light signs",
    "description": "Custom-shaped LED sign with point lighting, built to be seen at night.",
    "image": "images/led-sign-night.jpg"
  },
  "vilis-install": {
    "id": "vilis-install",
    "title": "On-site installation",
    "category": "Facade signs",
    "description": "Our crew mounting the Vilis sign from a lift — installation is part of the job.",
    "image": "images/installation-vilis.jpg"
  },
  "light-production": {
    "id": "light-production",
    "title": "Light sign in production",
    "category": "Light signs",
    "description": "Illuminated letters and logo being assembled in our own workshop.",
    "image": "images/light-sign-production.jpg"
  },
  "letters": {
    "id": "letters",
    "title": "Volume letters",
    "category": "Volume letters",
    "description": "3D letters cut and assembled by hand before they get their faces and lights.",
    "image": "images/volume-letters-production.jpg"
  },
  "clinic-windows": {
    "id": "clinic-windows",
    "title": "Clinic window graphics",
    "category": "Window graphics",
    "description": "Branded window and door graphics for the Rivne Cancer Center clinic.",
    "image": "images/window-graphics-clinic.jpg"
  },
  "kava-cafe": {
    "id": "kava-cafe",
    "title": "Kava & Lyudy cafe",
    "category": "Window graphics",
    "description": "Cafe sign plus hand-drawn style window stickers that invite people in.",
    "image": "images/cafe-sign-kava.jpg"
  },
  "milk-cutout": {
    "id": "milk-cutout",
    "title": "Printed product cutout",
    "category": "Printing",
    "description": "Large-format print cut to shape for a dairy product display.",
    "image": "images/printed-cutout-milk.jpg"
  },
  "carwash": {
    "id": "carwash",
    "title": "Car wash control panel",
    "category": "Printing",
    "description": "Durable printed panel with clear instructions for a self-service car wash.",
    "image": "images/carwash-panel.jpg"
  }
};

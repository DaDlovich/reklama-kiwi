# Reklama KiWi — website

Sign-making studio in Rivne, Ukraine. Plain HTML, no build step.

## Put this on GitHub

1. On github.com, click **+** → **New repository**, give it a name (for example `reklama-kiwi`), keep it **Public**, then click **Create repository**.
2. On the empty repository page, click **uploading an existing file**.
3. Open this folder on your computer and drag **all the files inside it** (not the folder itself, and not a `.zip`) onto the page. Wait until the bar finishes, then click **Commit changes**.
4. Go to **Settings** → **Pages**. Under **Build and deployment**, set **Source** to **Deploy from a branch** and **Branch** to `main` / `/ (root)`, then **Save**.
5. After a minute or two the site is live at `https://YOUR-USERNAME.github.io/reklama-kiwi/`.

## Use www.kiwireklama.com.ua

The `CNAME` file in this folder already says `www.kiwireklama.com.ua`.

1. In the repository, **Settings** → **Pages** → **Custom domain** → type `www.kiwireklama.com.ua` → **Save**.
2. At the company where you bought the domain, add the DNS records GitHub shows you there:
   - `A` records for `kiwireklama.com.ua` pointing to GitHub's four IP addresses
   - a `CNAME` record for `www` pointing to `YOUR-USERNAME.github.io`
3. Tick **Enforce HTTPS** once the check marks turn green.

## Files

| File | What it is |
| --- | --- |
| `index.html` | Home page |
| `work.html` | Our Work — photos, category filter, photo pop-up |
| `services.html` | Services |
| `contact.html` | Contact |
| `styles.css` | Colours, fonts, layout |
| `lightbox.css` | Look of the photo pop-up |
| `script.js` | Phone menu, photo filter, photo pop-up |
| `works-data.js` | Titles and descriptions shown in the photo pop-up |
| `images/` | Photos, logo, browser tab icon |
| `CNAME` | The custom domain for GitHub Pages |
| `.nojekyll` | Tells GitHub Pages not to process the files |

## Editing

All text lives in the `.html` files. Photo titles and descriptions live in
`works-data.js`. To see changes, open `index.html` in a browser.

Fonts are loaded from Google Fonts, so they only appear when you are online.
